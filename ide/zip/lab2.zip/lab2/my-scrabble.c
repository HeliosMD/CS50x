#include <cs50.h>
#include <ctype.h>
#include <stdio.h>
#include <string.h>

int check(char a);

int main(void)
{
    int scores[2];
    for (int i = 0; i < 2; i++)
    {
        string s = get_string("Player %i: ", i);
        for (int j = 0, n = strlen(s); j < n; j++)
        {
            scores[i] += check(s[j]);
        }
    }
    if (scores[0] > scores[1])
    {
        printf("Player 1 wins!\n");
    }
    else (scores[0] < scores[1])
    {
        printf("Player 2 wins!\n");
    }
    else
    {
        printf("Tie!\n");
    }
}

int check(char a)
{
    a = toupper(a);
    int score[26];
    score[0] = 1;
    score[1] = 3;
    score[2] = 3;
    score[3] = 2;
    score[4] = 1;
    score[5] = 4;
    score[6] = 2;
    score[7] = 4;
    score[8] = 1;
    score[9] = 8;
    score[10] = 5;
    score[11] = 1;
    score[12] = 3;
    score[13] = 1;
    score[14] = 1;
    score[15] = 3;
    score[16] = 10;
    score[17] = 1;
    score[18] = 1;
    score[19] = 1;
    score[20] = 1;
    score[21] = 4;
    score[22] = 4;
    score[23] = 8;
    score[24] = 4;
    score[25] = 10;
    return score[a - 65];
}